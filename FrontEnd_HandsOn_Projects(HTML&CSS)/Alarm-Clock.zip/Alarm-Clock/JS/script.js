/* ----Variable------ */
const dateFace = document.getElementById('date');
const timeFace = document.getElementById('time');
const stopAlarm = document.querySelector('.stop-alarm');
const list = document.getElementById('alarm-list');
const audio = new Audio("/ASSETS/alarm.mp3");
audio.loop = true;
let alarmTime = null;
let alarmTimeOut = null;


/* ---Date and Time------ */
function updateTime(){
    const date = new Date();
    let hr = date.getHours(),
    mnt = formatDigit(date.getMinutes()),
    sc = formatDigit(date.getSeconds()),
    dName = date.getDay(),
    month = date.getMonth(),
    dayNo = formatDigit(date.getDate()),
    yr = date.getFullYear(),
    mode = "AM";

    var mo = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var week = ["Sunday", "Monday", "Tusday", "Wednesday", "Thursday", "Friday", "Saturday"];

    if(hr==0){
        hr = 12;
    }

    if(hr>12){
        hr -=12;
        hr = formatDigit(hr);
        if(mnt > 00)mode = "PM";
    }

    dateFace.innerText = week[dName] + "," + mo[month] + "," + dayNo + "," + yr ;
    timeFace.innerText = hr + ":" + mnt +  ":" + sc + ":" + mode;

    function formatDigit(value){
        if(value < 10)return ('0'+value);
        return value;
    }
}

setInterval(updateTime, 1000);

/* -------Set-Alarm--------- */

function setAlarmTime(value){
    alarmTime = value;
}

function setAlarm(){
    if(alarmTime == null)
      return (alert("Please Fill The Date&Time For Alarm..."));
    if(alarmTime){
        const current = new Date();
        const timeToAlarm = new Date(alarmTime);
        console.log(timeToAlarm);
        if(timeToAlarm > current){
            // let hrs = timeToAlarm.getHours(),
            // mnts = timeToAlarm.getMinutes();
            // list.innerText = hrs + ":" + mnts;
            list.appendChild(alarmTime);
             const timeOut = timeToAlarm.getTime() - current.getTime();
             alarmTimeOut = setTimeout(function(){
                stopAlarm.style.visibility='visible';
                audio.play();
             }, timeOut);

             alert("Your Alarm is set....");
        }
    }
}

/* -------Clear Alarm--------- */

function clearAlarm(){
    audio.pause();
    if(alarmTimeOut){
        stopAlarm.style.visibility='hidden';
        clearInterval(alarmTimeOut);
        alert("Your Alarm has been cleared...");
    }
}

